<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <style>
        p{
            font-size: 15px;
            font-weight: bold;
        }

        table{
            font-size: 20px;
        }
    </style>
</head>
<body>
    <h3>Hoi</h3>

     <div class="">
            <img src="{{public_path('img/Group 1.svg')}}" alt="">
            <i><b><h1 class="">Omah Kunci</h1></b></i>
        </div>
</body>
</html>