<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

define("config_nota_kecil",[
    "realtime_tanggal" => true,
    "margin_atas"=> 1.5, //satuan cm 
    "margin_kiri"=> 1.5, // satuan cm 
    "ukuran_font" =>  10, // satuan pt
]);


define("config_nota_besar", [
    "margin_atas"=> 1.5, //satuan cm 
    "margin_kiri"=> 1.5, // satuan cm
    "ukuran_font" =>  10, // satuan pt
]);
